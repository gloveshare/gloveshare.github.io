<?
@header("content-type:text/json;charset=UTF-8");
$qq=$_GET['qq'];
if($qq==""){
 $result = array("code" => -1, "msg" => "获取最新说说失败！原因:请输入QQ号!");
 exit(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
}else{
    $url1="https://apibb.rjk66.cn/qqid.php?qq=";
	$url = $url1.$qq;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER,0);
    $output = curl_exec($ch);
    $de_json = json_decode($output, true); 
    curl_close($ch);
    if($de_json['code']==-1){
      $result = array("code" => -1, "msg" => $de_json['msg']);
      exit(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));  
    }elseif($de_json['code']==0){
      $result=array("code"=>0,"msg"=>"获取说说列表成功！","msglist"=>$de_json['msglist']);
      exit(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));  
    }elseif($de_json==""){
      $result=array("code" => -1, "msg" => "获取最新说说失败！原因:我好像卡了，请重试!");
      exit(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    }else{
      $result=array("code" =>404, "msg" => "系统出错！");
      exit(json_encode($result,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));  
    }
    
}
?>