
<!doctype html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FancyPig猪头领赞小工具2.0</title>
    <link rel="stylesheet" href="layui/css/layui.css">
      <script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
  <!--[if lt IE 9]>
	<script src="//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="//lib.baomitu.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body style="background-color: #F2F2F2">
<div class="layui-container">
    <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
        <legend>猪头每日领赞福利</legend>
    </fieldset>
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header">使用说明：</div>
                <div class="layui-card-body">
                    打开QQ扫码以后，确认登录<br>
                    然后返回此页面领赞！<br>
                    猪头博客：<a href="https://www.iculture.cc"style="color: #ff0000;">FancyPig's blog</a><br>
                    源码下载：<a href="https://www.iculture.cc" style="color: #ff0000;">猪头每日领赞源码分享</a>
                </div>
            </div>
        </div>
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header">活动说明：</div>
                <div class="layui-card-body">
                    1、为回馈新老用户，本平台决定送出千万名片赞<br>
                    2、每人每天可免费领取500-5000个赞<br>
                    3、更多羊毛福利加入<a href="https://jq.qq.com/?_wv=1027&k=IHsI30fx" style="color: #ff0000;">福利通知群265586</a><br>
                    4、更多技术分享<a href="https://www.iculture.cc/qun" color="blue" style="color: #ff0000;">官方通知群</a><br>
                </div>
            </div>
        </div>
             <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header">常见问题：</div>
                <div class="layui-card-body">
                <script src="layui/msg.js?=v4" type="text/javascript"></script>
                提示无法识别二维码：<a href="javascript:;" onclick="Solution(1)"><span style="color: #ff0000;">点击查看解决方案</a><br>
                提示登录信息已过期：<a href="javascript:;" onclick="Solution(2)"><span style="color: #ff0000;">点击查看解决方案</a><br>
                如未显示二维码或已过期：<a href="javascript:location.reload();"><span style="color: #ff0000;">请点击刷新<img src="https://jlwz.cn/Template/default/img/jlwz_new.png" alt="刷新" style="vertical-align: middle;width: 18px;"></a><br>
                </div>
            </div>
        </div>
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header">在线领赞</div>
                <div class="layui-card-body">

                    <div class="layui-tab layui-tab-brief" lay-filter="tab">
                        <ul class="layui-tab-title" style="text-align: center">
                            <li class="layui-this">扫码认证</li>
                            <li>免费福利</li>
                            <li>更多工具</li>
                        </ul>
                        <div class="layui-tab-content">
                            <div class="layui-tab-item layui-show">
                                <blockquote class="layui-elem-quote layui-quote-nm" id="msg">
                                    请使用手机QQ扫码登录
                                </blockquote>
                                <fieldset class="layui-elem-field site-demo-button">
                                    <legend style="text-align: center">在线认证(QQ扫码)</legend>
                                    <div id="qrimg" style="text-align: center;padding: 10px"></div>
                                   <a href="javascript:location.reload();"><span style="color: #ff0000;"><p style="text-align: center;">点击刷新二维码</p><center><img src="https://jlwz.cn/Template/default/img/jlwz_new.png" alt="刷新" style="vertical-align: middle;width: 18px;"><center></a>
                                </fieldset>
                            </div>
                            <div class="layui-tab-item">
                                <blockquote class="layui-elem-quote">请先QQ扫码后领取：</blockquote>
                                <form name="from1" method="post" class="layui-form layui-form-pane" action="">
                                    <br>
                                    <label class="layui-label"><h2>领取空间人气</h2></label><br>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">领取账号</label>
                                        <div class="layui-input-block">
                                            <input id="rqqq" name="rqqq" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                            </div>
                                    </div>
                                </form>
                                <button type="button" class="layui-btn layui-btn-fluid" id="lqrq" name="lqrq">领取空间人气</button>             
                                <form name="from2" method="post" class="layui-form layui-form-pane" action="">
                                    <br>
                                    <label class="layui-label"><h2>领取说说赞</h2></label><br>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">领取账号</label>
                                        <div class="layui-input-block">
                                            <input id="sszqq" name="sszqq" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                        </div>
                                    </div>
                                     <div class="layui-form-item">
                                        <label class="layui-form-label">说说ID</label>
                                        <div class="layui-input-block" >
                                            <input id="ssid" name="ssid" type="text" class="layui-input" value="" disabled/>
                                        </div>
                                    </div>
                                    
                                </form>
                                <div class="layui-item">
                                      <label class="layui-form-label" >选择说说:</label>
                                            <div class="layui-input-block">
                                                <select id="interest" style="width:100%;height:35px"><option value="" selected="">请先点击获取说说ID</option></select>
                                            </div>
                                </div>
                                 <div class="layui-form-item">
                                <button type="button" class="layui-btn layui-btn-warm" name="setssid" id="setssid">获取说说ID</button>  
                                <button type="button" class="layui-btn layui-btn-lg layui-btn-normal" name="lqssz" id="lqssz">领取说说赞</button>
                                </div>

                            </div>
                            <div class="layui-tab-item">
                                <blockquote class="layui-elem-quote">自定义手机型号</blockquote>
                                     <div class="layui-card-body">
                                     <span><h2>提示：</h2></span>1、请先扫码后再来使用本工具<br>
                                          2、本工具可以修改QQ在线手机型号<br>
                                          <!-- 3、<a style='color:#d71345' href="javascript:void(0);" Onclick="xgt()">点击查看效果图</a><br> -->
                                    </div> 
                                    <div class="layui-form-item">
                                        <form name="from3" method="post" class="layui-form layui-form-pane" action="">
                                        <label class="layui-form-label">领取账号</label>
                                        <div class="layui-input-block">
                                                 <input id="zdyqq" name="zdyqq" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                        </div>
                                        </form>    
                                         <button type="button" class="layui-btn layui-btn-fluid" id="zdyxg" name="zdyxg">立即修改</button>
                                    </div>
                                </hr>
                               <blockquote class="layui-elem-quote">小米修改步数</blockquote>
                                     <div class="layui-card-body">
                                     <span><h2>提示：</h2></span>1、请先扫码后再来使用本工具<br>
                                          2、本工具可以修改微信支付宝步数<br>
                                          <!-- 3、<a style='color:#d71345' href="javascript:void(0);" Onclick="sbjc()">点击查看使用教程</a><br> -->
                                    </div> 
                                    <div class="layui-form-item">
                                        <form name="from4" method="post" class="layui-form layui-form-pane" action="">
                                        <div class="layui-form-item">
                                             <label class="layui-form-label">领取Q Q</label>
                                             <div class="layui-input-block">
                                                 <input id="bsqq" name="bsqq" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                             </div>
                                        </div>
                                        <div class="layui-form-item">
                                             <label class="layui-form-label">小米账号</label>
                                             <div class="layui-input-block">
                                                 <input id="bsuser" name="bsuser" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                             </div>
                                        </div>                                        
                                        <div class="layui-form-item">
                                             <label class="layui-form-label">小米密码</label>
                                             <div class="layui-input-block">
                                                 <input id="bspass" name="bspass" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                             </div>
                                        </div>
                                        <div class="layui-form-item">
                                             <label class="layui-form-label">修改的步数</label>
                                             <div class="layui-input-block">
                                                 <input id="bsnum" name="bsnum" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="" >
                                             </div>
                                        </div>
                                        </form>    
                                         <button type="button" class="layui-btn layui-btn-fluid" id="bstj" name="bstj">立即修改</button>
                                    </div>
                                    
                            </div>                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body" style="text-align: center">
                    Copyright ©2021 
                </div>
            </div>
        </div>

    </div>
</div>
<script>
    function xgt(){
        layer.alert('查看效果图</br><img style="max-width:100%;" src="./xgt.jpg" >  ');
    }
    function sbjc(){
        layer.open({
            type: 2,
            title: '使用教程',
            shadeClose: true,
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['380px', '90%'],
            content: '/sbjc.html' //iframe的url
        }); 
    }
</script>

<script src="//api.kit9.cn/Apijs/model/model.js"></script>
<script src="layui/layui.all.js"></script>
<script src="layui/index.js"></script>
</body>
</html>