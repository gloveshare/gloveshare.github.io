<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>QQ自定义在线机型状态</title>
  <link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="./layui/css/layui.css" rel="stylesheet"/>
  <script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
  <script src="//lib.baomitu.com/layer/3.1.1/layer.js"></script>
  <!--[if lt IE 9]>
	<script src="//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="//lib.baomitu.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body>
<div class="container">
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block" style="float: none;">
<br>
	<div class="panel panel-default">
	<div class="panel-heading"><h3 class="panel-title">
	自定义在线机型状态
	</div>
	<div class="panel-body">
		<div class="list-group" style="text-align: center;">
		<blockquote class="layui-elem-quote layui-quote-nm">
        <li>1、首先点右边→→<a href="https://1105583577.urlshare.cn" class="btn btn-success btn-xs">点我获取设备IMEI</a> </li>
        <li>2、跳转QQ后点击【<span style="color:red">设备信息</span>】后在根据自己机型</li>
        <li>3、<a href="https://www.iculture.cc/demo/qq_zan2.0/demo-imei.png" class="btn btn-success btn-xs">点击查看设置图片</a></li>
        <li>扫二维码→允许登录→点击执行</li>
        <li>本功能需要有SVIP才可实现 没有提交没用</li>
        </blockquote>
				<div class="list-group-item list-group-item-light" style="font-weight: bold;" id="login">
				<span id="loginmsg">使用QQ手机版扫描二维码</span><span id="loginload" style="padding-left: 10px;color: #790909;">.</span>
			</div>
			<div class="list-group-item" id="qrimg"></div>
			<div class="list-group-item" id="qrLogin"><a href="#" onclick="qrLogin()" class="layui-btn layui-btn-primary layui-btn-radius">点击执行</a></div>
		</div>
		<div class="list-group" id="PhoneInfo" style="display: none;">
			<div class="list-group-item" style="text-align: center;">
			    <img class="layui-anim-rotate" src="https://q4.qlogo.cn/headimg_dl?spec=100&dst_uin=663962" width="80" style="border-radius: 50%;opacity: 0.80;" id="avatar">
			</div><hr>
           <form class="layui-form layui-form-pane" action="">	
			<div class="layui-form-item">
            <label class="layui-form-label">QQ</label>
            <div class="layui-input-block">
              <input type="text" id="qq" class="layui-input" required="请输入QQ">
            </div>
          </div>
			<div class="layui-form-item">
            <label class="layui-form-label">skey</label>
            <div class="layui-input-block">
              <input type="text" id="skey" class="layui-input" required="请输入skey">
            </div>
          </div>
			<div class="layui-form-item">
            <label class="layui-form-label">pt4_token</label>
            <div class="layui-input-block">
              <input type="text" id="pt4_token" class="layui-input" required="请输入pt4_token">
            </div>
          </div>
			<div class="layui-form-item">
            <label class="layui-form-label">自定义机型</label>
            <div class="layui-input-block">
              <input type="text" id="text" class="layui-input"  required="" value="iPhone 11 Pro Max">
            </div>
          </div>
			<div class="layui-form-item">
            <label class="layui-form-label">手机IMEI码</label>
            <div class="layui-input-block">
              <input type="text" id="imei" class="layui-input" required="" placeholder="请输入imei">
            </div>
          </div>
			<div class="list-group-item" id="Post" style="text-align: center;"><a href="#" onclick="Post()" class="layui-btn layui-btn-primary layui-btn-radius">点击执行</a></div>
		</div>
	</div>
</div>
<script src="layui/layui.all.js"></script>
<script src="//api.kit9.cn/Apijs/model/model.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		GetQR();
		interval1=setInterval(loginload,500);
	});
	var interval1,isupdate,mUin,mSkey,mPskey,mToken,mOpenid;
	function GetQR(force){
		force = force || false;
			clearInterval(interval1);
		var qrsig = getCookie('qrsig');
		var qrimg = getCookie('qrimg');
		if(qrsig != null && qrimg != null && force == false){
			$('#qrimg').attr('qrsig',qrsig);
			$('#qrimg').html('<img id="qrcodeimg" onclick="GetQR(true)" src="data:image/png;base64,'+qrimg+'" title="点击刷新">');
		}else{
			$.getJSON('login.php',{do:'getqrpic',r:Math.random(1)}, function(d) {
				if(d.saveOK ==0){
					setCookie('qrsig',d.qrsig);
					setCookie('qrimg',d.data);
					$('#qrimg').attr('qrsig',d.qrsig);
					$('#qrimg').html('<img id="qrcodeimg" onclick="GetQR(true)" src="data:image/png;base64,'+d.data+'" title="点击刷新">');
				}else{
					layer.alert(d.msg);
				}
			});

		}
	}
</script>
</body>
</html>