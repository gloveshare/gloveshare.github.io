layui.use('element', function () {
    var $ = layui.jquery, element = layui.element, id;
    getqrocde();
    function getqrocde() {
        $.ajax({
            url: 'https://qr.rjk66.cn/api/gethzqr',
            type: 'GET',
            data: {},
            dataType: 'json',
            success: function (data) {
                window.data = data;
                $('#qrimg').html('<img style="max-width:147px;max-height:147px;" src="' + data.data.qrcode + '" >');
                id = data.data.id;
                if (window.id) {
                    window.clearInterval(window.id);
                }
                window.id = setInterval(getresult, 3000);
            },
            error: function () {
                layer.alert("二维码获取失败!");
            }
        });
    }
    function getresult() {
        var r = Date.parse(new Date());
        var qq;
        $.ajax({
            url: url = 'https://qr.rjk66.cn/api/hzqrlogin',
            aycnc: false,
            type: 'GET',
            data: { id: id, r: r },
            dataType: 'json',
            success: function (data) {
                if (data.qrstate == 4) {
                    qq = data.uin;
                    window.clearInterval(window.id);
                    $('#msg').html(data.uin + '登录成功' + "<br>" + data.msg);
                    element.tabAdd('tab', {
                        title: '领取信息'
                        , content: '<blockquote class="layui-elem-quote">领取成功，领取信息 ：</blockquote><form class="layui-form layui-form-pane" action=""><img id="qqtx" style="width:200px;height:200px"/><div class="layui-form-item"><label class="layui-form-label">领取账号</label><div class="layui-input-block"><input name="qq" type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="123456789" disabled></div></div><div class="layui-form-item"><label class="layui-form-label">领取数量</label><div class="layui-input-block"><input type="text"  required lay-verify="required" placeholder="" autocomplete="off" class="layui-input" value="500~5000" disabled></div></div></form>'
                        , id: 'lz'
                    });
                    $("input[name='qq']").attr('value', qq);
                    $('#qqtx').attr('src', "https://q4.qlogo.cn/headimg_dl?dst_uin=" + qq + "&spec=640");
                } else {
                    $('#msg').html(data.msg);
                }
            },
            error: function () {
                console.log('登录结果获取失败！');
            }
        });
    }

    $("#lqrq").on('click', function () {
        var rqqq = from1.rqqq.value;
        $.ajax({
            url: url = './rq.php',
            type: 'GET',
            data: { qq: rqqq },
            dataType: 'json',
            success: function (data) {
                if (data.code == 0) {
                    layer.alert(data.msg);
                } else {
                    layer.alert(data.msg);
                }

            },
            error: function () {
                console.log('服务器链接错误！');
            }
        });
    });
    
    $("#setssid").on('click', function () {
        var sszqq = from2.sszqq.value;
        $.ajax({
            url: url = './qqid.php',
            type: 'GET',
            data: { qq: sszqq },
            dataType: 'json',
            success: function (data) {
                if (data.code == 0) {
                    layer.alert(data.msg);
                    var msglist = data.msglist;
                    document.all.interest.options.length = 0; 
                     for(var o in data.msglist){
                         $("#interest").append('<option value="' + data.msglist[o].tid + '">' + data.msglist[o].content + '</option>'); 
                      }  
                   
                } else {
                    layer.alert(data.msg);
                }
            },
            error: function () {
                console.log('服务器链接错误！');
            }
        });
    });
    $("#lqssz").on('click', function () {
        var sszqq = from2.sszqq.value;
        var ssid = interest.value;
        $.ajax({
            url: url = './ssz.php',
            type: 'GET',
            data: {qq:sszqq,ssid:ssid},
            dataType: 'json',
            success: function (data) {
                if (data.code == 6)
                {
                    layer.alert(data.msg);
                } else {
                    layer.alert(data.msg);
                }
            },
            error: function () {
                console.log('服务器链接错误！');
            }
        });
    });
    $("#zdyxg").on('click', function () {
        var zdyqq = from3.zdyqq.value;
        $.ajax({
            url: url = './rq.php',
            type: 'GET',
            data: { qq: zdyqq },
            dataType: 'json',
            success: function (data) {
                if (data.code == 6) {
                    layer.open({
                    type: 2,
                    title: '自定义在线手机型号',
                    shadeClose: true,
                     shade: false,
                     maxmin: true, //开启最大化最小化按钮
                    area: ['380px', '90%'],
                    content: './zdymp.php' //iframe的url
                  });
                } else {
                    layer.alert(data.msg);
                }

            },
            error: function () {
                console.log('服务器链接错误！');
            }
        });
    });
    $("#bstj").on('click', function () {
        var bsqq = from4.bsqq.value;
        var bsuser = from4.bsuser.value;
        var bspass = from4.bspass.value;
        var bsnum = from4.bsnum.value;
        $.ajax({
            url: url = './rq.php',
            type: 'GET',
            data: { qq: bsqq},
            dataType: 'json',
            success: function (data) {
                if (data.code == 6) {
                      $.ajax({
                         url: url = 'https://xmyd.jxxlr.cn/api.php',
                         type: 'GET',
                         data: {phone:bsuser,password:bspass,steps:bsnum},
                         dataType: 'json',
                         success: function (data) {
                             if (data.code == 1) {
                                 layer.alert("刷步成功！您的步数已更新为："+bsnum+"</br>"+"Tis:每次提交间隔为一分钟！");  
                             } else {
                                 layer.alert("刷步失败，原因：密码错误、提交频繁或系统出错，请稍后重试！");
                             }
                           }
                    });
                } else {
                    layer.alert(data.msg);
                }

            },
            error: function () {
                console.log('服务器链接错误！');
            }
        });
    });
    $("#interest").on('change',function(){
            var a = interest.value;
            $("#ssid").attr('value',a);
    }); 
    
   
});
